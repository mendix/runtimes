/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ca/roc",{"field-sat-relative+0":"aquest dissabte","field-sat-relative+1":"dissabte que ve","field-dayperiod":"a. m./p. m.","field-sun-relative+-1":"diumenge passat","field-mon-relative+-1":"dilluns passat","field-minute":"minut","field-day-relative+-1":"ahir","field-weekday":"dia de la setmana","field-day-relative+-2":"abans-d'ahir","field-era":"era","field-hour":"hora","field-sun-relative+0":"aquest diumenge","field-sun-relative+1":"diumenge que ve","field-wed-relative+-1":"dimecres passat",
"field-day-relative+0":"avui","field-day-relative+1":"dem\u00e0","field-day-relative+2":"dem\u00e0 passat","dateFormat-long":"d MMMM 'de' y G","field-tue-relative+0":"aquest dimarts","field-zone":"zona","field-tue-relative+1":"dimarts que ve","field-week-relative+-1":"la setmana passada","dateFormat-medium":"dd/MM/y G","field-year-relative+0":"enguany","field-year-relative+1":"l'any que ve","field-sat-relative+-1":"dissabte passat","field-year-relative+-1":"l'any passat","field-year":"any","field-fri-relative+0":"aquest divendres",
"field-fri-relative+1":"divendres que ve","field-week":"setmana","field-week-relative+0":"aquesta setmana","field-week-relative+1":"la setmana que ve","field-month-relative+0":"aquest mes","field-month":"mes","field-month-relative+1":"el mes que ve","field-fri-relative+-1":"divendres passat","field-second":"segon","field-tue-relative+-1":"dimarts passat","field-day":"dia","field-mon-relative+0":"aquest dilluns","field-mon-relative+1":"dilluns que ve","field-thu-relative+0":"aquest dijous","field-second-relative+0":"ara",
"dateFormat-short":"dd/MM/y GGGGG","field-thu-relative+1":"dijous que ve","dateFormat-full":"EEEE d MMMM 'de' y G","field-wed-relative+0":"aquest dimecres","field-wed-relative+1":"dimecres que ve","field-month-relative+-1":"el mes passat","field-thu-relative+-1":"dijous passat"});
