/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sl/currency",{HKD_displayName:"hongkon\u0161ki dolar",CHF_displayName:"\u0161vicarski frank",JPY_symbol:"\u00a5",CAD_displayName:"kanadski dolar",CNY_displayName:"kitajski juan renminbi",USD_symbol:"$",AUD_displayName:"avstralski dolar",JPY_displayName:"japonski jen",CAD_symbol:"CAD",USD_displayName:"ameri\u0161ki dolar",GBP_displayName:"britanski funt",EUR_displayName:"evro"});
