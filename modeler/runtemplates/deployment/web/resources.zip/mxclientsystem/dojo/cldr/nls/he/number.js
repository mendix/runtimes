/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/he/number",{group:",",percentSign:"%",exponential:"E",scientificFormat:"#E0",percentFormat:"#,##0%",list:";",infinity:"\u221e",minusSign:"\u200e-",decimal:".",superscriptingExponent:"\u00d7",nan:"NaN",perMille:"\u2030",decimalFormat:"#,##0.###",currencyFormat:"#,##0.00\u00a0\u00a4",plusSign:"\u200e+","decimalFormat-long":"\u200f000 \u05d8\u05e8\u05d9\u05dc\u05d9\u05d5\u05df","decimalFormat-short":"000T"});
