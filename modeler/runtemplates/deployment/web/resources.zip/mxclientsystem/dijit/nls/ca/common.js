//>>built
define("dijit/nls/ca/common",{buttonOk:"D'acord",buttonCancel:"Cancel\u00b7la",buttonSave:"Desa",itemClose:"Tanca"});
