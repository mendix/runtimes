//>>built
define("dijit/nls/ro/loading",{loadingState:"\u00cenc\u0103rcare...",errorState:"Ne pare r\u0103u, a ap\u0103rut o eroare "});
