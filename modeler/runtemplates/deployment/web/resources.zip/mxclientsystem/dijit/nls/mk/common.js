//>>built
define("dijit/nls/mk/common",{buttonOk:"OK",buttonCancel:"\u041e\u0442\u043a\u0430\u0436\u0438",buttonSave:"\u0417\u0430\u0447\u0443\u0432\u0430\u0458",itemClose:"\u0417\u0430\u0442\u0432\u043e\u0440\u0438"});
