//>>built
define("dijit/nls/cs/loading",{loadingState:"Prob\u00edh\u00e1 na\u010d\u00edt\u00e1n\u00ed...",errorState:"Omlouv\u00e1me se, do\u0161lo k chyb\u011b"});
