//>>built
define("dijit/nls/da/common",{buttonOk:"OK",buttonCancel:"Annull\u00e9r",buttonSave:"Gem",itemClose:"Luk"});
