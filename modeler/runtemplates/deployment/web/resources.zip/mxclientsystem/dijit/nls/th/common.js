//>>built
define("dijit/nls/th/common",{buttonOk:"\u0e15\u0e01\u0e25\u0e07",buttonCancel:"\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01",buttonSave:"\u0e1a\u0e31\u0e19\u0e17\u0e36\u0e01",itemClose:"\u0e1b\u0e34\u0e14"});
