//>>built
define("dijit/nls/tr/loading",{loadingState:"Y\u00fckleniyor...",errorState:"\u00dczg\u00fcn\u00fcz, bir hata olu\u015ftu"});
