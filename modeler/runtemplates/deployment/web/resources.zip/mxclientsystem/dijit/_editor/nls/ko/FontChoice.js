//>>built
define("dijit/_editor/nls/ko/FontChoice",{fontSize:"\ud06c\uae30",fontName:"\uae00\uaf34",formatBlock:"\uc11c\uc2dd",serif:"serif","sans-serif":"sans-serif",monospace:"monospace",cursive:"cursive",fantasy:"fantasy",noFormat:"\uc5c6\uc74c",p:"\ub2e8\ub77d",h1:"\uc81c\ubaa9",h2:"\ubd80\uc81c\ubaa9",h3:"\ud558\uc704 \ubd80\uc81c\ubaa9",pre:"\uc11c\uc2dd\uc774 \uc9c0\uc815\ub428",1:"\uac00\uc7a5 \uc791\uac8c",2:"\uc870\uae08 \uc791\uac8c",3:"\uc791\uac8c",4:"\uc911\uac04",5:"\ud06c\uac8c",6:"\uc870\uae08 \ud06c\uac8c",
7:"\uac00\uc7a5 \ud06c\uac8c"});
