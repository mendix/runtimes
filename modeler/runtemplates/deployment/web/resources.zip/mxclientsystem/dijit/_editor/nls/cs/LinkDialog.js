//>>built
define("dijit/_editor/nls/cs/LinkDialog",{createLinkTitle:"Vlastnosti odkazu",insertImageTitle:"Vlastnosti obr\u00e1zku",url:"Adresa URL:",text:"Popis:",target:"C\u00edl:",set:"Nastavit",currentWindow:"Aktu\u00e1ln\u00ed okno",parentWindow:"Nad\u0159\u00edzen\u00e9 okno",topWindow:"Okno nejvy\u0161\u0161\u00ed \u00farovn\u011b",newWindow:"Nov\u00e9 okno"});
