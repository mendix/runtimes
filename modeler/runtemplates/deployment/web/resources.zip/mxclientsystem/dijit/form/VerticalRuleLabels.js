//>>built
define("dijit/form/VerticalRuleLabels",["dojo/_base/declare","./HorizontalRuleLabels"],function(a,b){return a("dijit.form.VerticalRuleLabels",b,{templateString:'\x3cdiv class\x3d"dijitRuleContainer dijitRuleContainerV dijitRuleLabelsContainer dijitRuleLabelsContainerV"\x3e\x3c/div\x3e',_positionPrefix:'\x3cdiv class\x3d"dijitRuleLabelContainer dijitRuleLabelContainerV" style\x3d"top:',_labelPrefix:'"\x3e\x3cspan class\x3d"dijitRuleLabel dijitRuleLabelV"\x3e',_calcPosition:function(a){return 100-a},
_isHorizontal:!1})});
