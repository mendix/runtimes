//>>built
define("dijit/form/nls/sv/Textarea",{iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"redigeringsomr\u00e5desram"});
