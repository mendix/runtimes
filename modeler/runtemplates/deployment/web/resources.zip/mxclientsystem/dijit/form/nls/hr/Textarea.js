//>>built
define("dijit/form/nls/hr/Textarea",{iframeEditTitle:"podru\u010dje ure\u0111ivanja",iframeFocusTitle:"okvir podru\u010dja ure\u0111ivanja"});
