//>>built
define("dijit/PopupMenuBarItem",["dojo/_base/declare","./PopupMenuItem","./MenuBarItem"],function(a,b,c){return a("dijit.PopupMenuBarItem",[b,c._MenuBarItemMixin],{})});
